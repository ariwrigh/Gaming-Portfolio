﻿using UnityEngine;
using System.Collections;

public class AlterWinCon : MonoBehaviour {
	private WinCondition winConScript;

	//use for initialization
	void Start(){
		winConScript = FindObjectOfType (typeof(WinCondition)) as WinCondition;
	}

	void OnTriggerEnter(Collider other){
		if (other.gameObject.tag == "Objective") {
			//incriment win condition by 1, variable is named conditions met
			winConScript.conditionsMet += 1;
			Debug.Log (winConScript.conditionsMet);
		}
	}

	void OnTriggerExit(Collider other){
		if (other.gameObject.tag == "Objective") {
			//incriment win condition by 1, variable is named conditions met
			winConScript.conditionsMet -= 1;
			Debug.Log (winConScript.conditionsMet);
		}
	}
}
