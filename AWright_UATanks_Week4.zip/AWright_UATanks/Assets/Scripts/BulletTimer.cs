﻿using UnityEngine;
using System.Collections;

public class BulletTimer : MonoBehaviour {
	public float destroyDelay = 5.0f;
	private float timeUntilDestroy;

	// Use this for initialization
	void Start () {
		timeUntilDestroy = destroyDelay;
	}
	
	// Update is called once per frame
	void Update () {
		timeUntilDestroy -= Time.deltaTime;
		if(timeUntilDestroy <= 0){
			DestroyObject (this.gameObject);
		}
	}
}
