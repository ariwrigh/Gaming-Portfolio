﻿using UnityEngine;
using System.Collections;

public class ActiveTrapBox : MonoBehaviour {

	void OnTriggerEnter(Collider other){
		//this will activate the trap boxes when an objective object colides with a win condition square
		for (int i = 0; i < this.transform.GetChildCount(); ++i)
		{
			this.transform.GetChild(i).gameObject.SetActive(true);
		}
	}
}
