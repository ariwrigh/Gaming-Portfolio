﻿using UnityEngine;
using System.Collections;

public class FailCondition : MonoBehaviour {
	void OnTriggerEnter(Collider other){
		if (other.gameObject.tag == "Player" || other.gameObject.tag == "Objective") {

			Application.LoadLevel ("failedMenu");
		}
		if (other.gameObject.tag == "Bullet") {
			Destroy (other.gameObject);	
		}
	}
}

