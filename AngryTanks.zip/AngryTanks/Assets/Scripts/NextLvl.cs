﻿using UnityEngine;
using System.Collections;

public class NextLvl : MonoBehaviour {
	private GameManager gameManager;
	// Use this for initialization
	void Start () {
		gameManager = FindObjectOfType (typeof(GameManager)) as GameManager;
	}
	
	// Update is called once per frame
	void Update () {
	}
	
	void OnMouseUp () {
		//if player has not beaten all three levels
		if (gameManager.levelsBeat > 2) {
			// load main menu as all 3 levels have been beat
			gameManager.levelsBeat = 0;
			Application.LoadLevel (0);

		}else {
			// load next level
			// levels beat is stored in game manager, each level beat incriments starting index of 4(level 1)
			Application.LoadLevel (4 + gameManager.levelsBeat);
		}
	}
}
