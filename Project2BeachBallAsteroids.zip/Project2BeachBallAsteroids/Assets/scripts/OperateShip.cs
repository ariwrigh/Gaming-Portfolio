﻿using UnityEngine;
using System.Collections;

public class OperateShip : MonoBehaviour {
	//Speed variable for rotating ship
	public int rotSpeed = 150;
	public int bulletSpeed = 500;
	public Rigidbody projectile;
	public Vector3 spawnPoint;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//regular movement
		// If the right button is pressed
		if (Input.GetButton("rotateRight"))
		{
			// rotate object right
			transform.Rotate(new Vector3(0,0,-rotSpeed) * Time.deltaTime);
		}
		
		// If the down button is pressed
		if (Input.GetButton("rotateLeft"))
		{
			// move object down
			transform.Rotate(new Vector3(0,0,rotSpeed)* Time.deltaTime);
		}

		//if fire button is pressed create bullet
		if (Input.GetButtonDown("fire"))
		{
			// launch bullet
			Rigidbody tempProjectile;
			tempProjectile = Instantiate (projectile, transform.position, transform.rotation) as Rigidbody;
			tempProjectile.AddForce(transform.right*bulletSpeed);


		}

		
		// If the quit button is pressed
		if (Input.GetButtonDown ("quit")) {
			// quit the program
			Application.Quit();
		}
	}
}
