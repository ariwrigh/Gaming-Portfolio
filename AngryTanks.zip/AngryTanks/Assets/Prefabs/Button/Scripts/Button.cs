﻿using UnityEngine;
using System.Collections;

public class Button : MonoBehaviour {
	
	public Sprite spriteUp; 
	public Sprite spriteOver;
	public Sprite spriteDown;
	
	public AudioClip soundUp;
	public AudioClip soundDown;
	
	public GameObject targetObject; 
	public SpriteRenderer theRenderer;
	
	// Use this for initialization
	void Start () {
		// If the renderer is not set, set it to this object
		if (theRenderer == null)
			theRenderer = gameObject.GetComponent<SpriteRenderer>();
		// If the Up sprite is not set, set it to the current sprite
		if (spriteUp == null)
			spriteUp = theRenderer.sprite;
		// If the down and over sprites are not set, set them to the up sprite
		if (spriteDown == null)
			spriteDown = spriteUp;
		if (spriteOver == null)
			spriteOver = spriteUp;
		// If the target object is not set, use this object
		if (targetObject == null)
			targetObject = gameObject;
		// Display the up sprite
		theRenderer.sprite = spriteUp;
	}
	
	// Update is called once per frame
	void Update () {
	}
	
	void OnMouseDown () {
		// Display the down sprite
		theRenderer.sprite = spriteDown;
		// Play our down sound
		if (soundDown != null) {
			AudioSource.PlayClipAtPoint (soundDown, transform.position);
		}
	}
	
	void OnMouseUp () {
		// Display the up sprite
		theRenderer.sprite = spriteUp;
		// Play our up sound
		if (soundUp!= null) {
			AudioSource.PlayClipAtPoint (soundUp, transform.position);
		}
		// This will call the function "OnButton" on every script attached to our target object
		targetObject.SendMessage("OnButton", SendMessageOptions.DontRequireReceiver);
	}
	
	void OnMouseEnter () {
		// Display the over sprite
		theRenderer.sprite = spriteOver;
	}
	
	void OnMouseExit (){
		// Display the up sprite
		theRenderer.sprite = spriteUp;
	}
}
