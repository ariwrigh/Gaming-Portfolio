﻿using UnityEngine;
using System.Collections;

public class EnemySpawn : MonoBehaviour {
	public GameObject enemy;
	private GameObject testing;
	public Transform[] waypoints;
	public Transform target;
	private AIController test;

	private Transform tf;


	// Use this for initialization
	void Start () {
		tf = gameObject.GetComponent<Transform> ();
	}

	public void spawnMazeEnemy(){
		GameObject newObject = (GameObject)Instantiate (enemy, tf.position, Quaternion.identity);
		testing = newObject;
		testing.GetComponent<AIController> ().updateWayPoints (waypoints);
		testing.GetComponent<AIController> ().aiPersonality = AIController.AIPersonality.Maze;


	}

	public void spawnPatrolEnemy(){
		GameObject newObject = (GameObject)Instantiate (enemy, tf.position, Quaternion.identity);
		testing = newObject;
		testing.GetComponent<AIController> ().updatePatrolPoints (waypoints);
		testing.GetComponent<AIController> ().aiPersonality = AIController.AIPersonality.Patrol;
		testing.GetComponent<AIController> ().target = GameObject.FindGameObjectWithTag ("Player").transform;

	}

	public void spawnChaseEnemy(){
		Debug.Log ("Chassing");
		GameObject newObject = (GameObject)Instantiate (enemy, tf.position, Quaternion.identity);
		Debug.Log ("New Ob made");
		testing = newObject;
		Debug.Log ("New ob assigned");
		testing.GetComponent<AIController> ().aiPersonality = AIController.AIPersonality.Chase;
		testing.GetComponent<AIController> ().target = GameObject.FindGameObjectWithTag ("Player").transform;
		Debug.Log ("Vars assigned");

	}
	public void spawnFleeEnemy(){
		Debug.Log ("Flee Started");
		GameObject newObject = (GameObject)Instantiate (enemy, tf.position, Quaternion.identity);
		testing = newObject;
		testing.GetComponent<AIController> ().aiPersonality = AIController.AIPersonality.Flee;
		testing.GetComponent<AIController> ().target = GameObject.FindGameObjectWithTag ("Player").transform;

	}
}