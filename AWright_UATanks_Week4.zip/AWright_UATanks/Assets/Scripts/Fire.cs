﻿using UnityEngine;
using System.Collections;

public class Fire : MonoBehaviour {

	public GameObject prefabBullet; // The prefab to hold our bullet
	public float minThrowForce = 200;//min force applied to bullet
	float throwForce; // The amount of force to use to throw the bullet
	public float fireDelay = 2.0f; //delay between shots
	public float destroyBulletTime = 5;

	public int bulletDamage = 10;
	[HideInInspector]
	public float timeUntilFire; //variable for holding time restriction
	public bool roundFired = false;//check for reload

	// Use this for initialization
	void Start () {
		throwForce = minThrowForce;
	}

	// Update is called once per frame
	void Update () {
		if (this.gameObject.tag == "Player" && Input.GetKeyDown(KeyCode.Space) && roundFired == false) {
			Shoot();
		} else if (this.gameObject.tag == "Player2" && Input.GetKeyDown(KeyCode.KeypadEnter) && roundFired == false){
			Shoot();
		}
		if (Time.time >= timeUntilFire) {//if time is creater than or equal to the delay reset fire flag to false
			roundFired = false;
		}
	}

	public void Shoot(){
		// Create a bullet and store it in a GameObject variable
		GameObject theBullet;
		theBullet = Instantiate (prefabBullet, transform.position + transform.forward, Quaternion.identity) as GameObject;
		theBullet.GetComponent<BulletData> ().destroyDelay = destroyBulletTime;//modifies destroy belay on bullet
		theBullet.GetComponent<BulletData> ().damage = bulletDamage;//modifies damage for bullet
		theBullet.GetComponent<BulletData>().owner = this.gameObject;//place holder for owner of bullet

		// Add force to the bullet we created -- the force vector is the object's forward direction scaled by the amount of force!
		theBullet.GetComponent<Rigidbody>().AddForce(throwForce * transform.forward);




		//set round fired to true
		roundFired = true;

		//begin timer
		timeUntilFire = Time.time + fireDelay;
	}
}