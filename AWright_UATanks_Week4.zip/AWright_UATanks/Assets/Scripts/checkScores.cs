﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class checkScores : MonoBehaviour {
	bool highScoreExists;
	bool player1ScoreExists;
	int highScore;
	int player1Score;
	public Text player1;
	public Text high;



	// Use this for initialization
	void Start () {
		//check for existing high score
		highScoreExists = PlayerPrefs.HasKey("HighScore");
		//if none set 0
		if (!highScoreExists) {
			PlayerPrefs.SetInt ("HighScore", 0);
			PlayerPrefs.Save ();
		}
		//check if player score field exists
		player1ScoreExists = PlayerPrefs.HasKey("Player1Score");
		//if none set 0
		if (!player1ScoreExists) {
			PlayerPrefs.SetInt ("Player1Score", 0);
			PlayerPrefs.Save ();
		}
		//pull saved data
		highScore = PlayerPrefs.GetInt("HighScore");
		player1Score = PlayerPrefs.GetInt ("Player1Score");

		//update scores
		if(player1Score > highScore){
			PlayerPrefs.SetInt ("HighScore", player1Score);
			PlayerPrefs.Save ();
			highScore = PlayerPrefs.GetInt("HighScore");
		}
			

		player1.text = player1Score.ToString();
		high.text = highScore.ToString();
	}
	

}
