﻿using UnityEngine;
using System.Collections;

public class SampleAIControll2 : MonoBehaviour {
	public enum AttackMode { Chase, Flee };
	public AttackMode attackMode;
	public Transform target;
	private TankData data;
	private TankMotor motor;  
	public float fleeDistance = 1.0f; 
	private Transform tf;//transform of current object


	// Use this for initialization
	void Start () {
		data = GetComponentInParent<TankData> ();
		motor = GetComponentInParent<TankMotor> ();
		tf = gameObject.GetComponent<Transform>();
	}
	
	// Update is called once per frame
	void Update () {
		if (attackMode == AttackMode.Chase) {
			motor.RotateTowards( target.position, data.turnSpeed );
			motor.Move (data.moveSpeed);
		}   
		else if (attackMode == AttackMode.Flee)
		{
			//Line between the player and ai
			Vector3 vectorToTarget = target.position - tf.position;

			// Set vector to be away from target instead of to it
			Vector3 vectorAwayFromTarget = -1 * vectorToTarget;

			// Adjust Magniture
			vectorAwayFromTarget.Normalize ();

			// Due to normalization, if we multiply by the distance that is the travel distance.
			vectorAwayFromTarget *= fleeDistance;

			// We can find the position in space we want to move to by adding our vector away from our AI to our AI's position.
			//     This gives us a point that is "that vector away" from our current position.
			Vector3 fleePosition = vectorAwayFromTarget + tf.position;
			motor.RotateTowards( fleePosition, data.turnSpeed );
			motor.Move (data.moveSpeed);
		} 
	}
}
