﻿using UnityEngine;
using System.Collections;

public class TankMotor : MonoBehaviour {
	//Character controller component
	private CharacterController characterController;
	private Transform tf;//transform of current object


	//on awake
	public void Awake() {
		tf = gameObject.GetComponent<Transform>();
	}


	//move function
	public void Move(float speed){
		Vector3 speedVector = tf.forward; //set speedVector to forward facing
		speedVector *= speed;//adjust for speed input
		characterController.SimpleMove (speedVector); //aplly movement
	}

	//rotate function
	public void Rotate(float speed){
		Vector3 rotateVector = Vector3.up;//creates variable and sets up rotation ability
		rotateVector *= speed *= Time.deltaTime; //Set rotation to be speed, based on time instead of frames
		tf.Rotate(rotateVector,Space.Self); //Rotate object by its position not by position in world

	}

	//RotateTowards (Target, speed) - rotates towards target, if possible
	//If we rtate, then return true, else (due to facing target) return false
	public bool RotateTowards (Vector3 target, float speed){
		Vector3 vectorToTarget;

		//The Vector to our target is the Difference between the target position and our position
		//OUr position minus target position aaligns the target
		vectorToTarget = target - tf.position;

		//Find the Quanternion that looks down that vector
		Quaternion targetRotation = Quaternion.LookRotation(vectorToTarget);

		//original class code
//		//if facing the target do not turn
//		if(targetRotation == tf.rotation){
//			return false;
//		}
//
//		//otherwise
//		//change our rotation so that we are closer to our target rotation, but never turn faster than our turn speed
//		// Note that we use Time.deltaTime becuase we want t turn in Degrees per Second not Degress per fram draw
//		tf.rotation = Quaternion.RotateTowards(tf.rotation, targetRotation, speed * Time.deltaTime);
//
//		//due to rotation return true
//		return true;

		//if not facing target, turn
		if(targetRotation != tf.rotation){
			tf.rotation = Quaternion.RotateTowards(tf.rotation, targetRotation, speed * Time.deltaTime);
			return true;
		}

		//else no rotation needed
		return false;
	}

	// Use this for initialization
	void Start () {
		// attach character controller to game object
		characterController = gameObject.GetComponent<CharacterController> ();     
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
