﻿using UnityEngine;
using System.Collections;

public class PlayerSpawn : MonoBehaviour {
	public GameObject player;
	public GameObject player1;
	public GameObject player2;
	private Transform tf;
	public bool playerUp = false;

	//multi player spawns
	public bool player1Up = false;
	public bool player2Up = false;

	// Use this for initialization
	void Start () {
		tf = gameObject.GetComponent<Transform> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(playerUp == true){
			spawnPlayer();
		}
		if(player1Up == true){
			spawnPlayer1();
		}
		if(player2Up == true){
			spawnPlayer2();
		}
	}

	void spawnPlayer(){
		Instantiate (player, tf.position, Quaternion.identity); 
		playerUp = false;
	}

	void spawnPlayer1(){
		Instantiate (player1, tf.position, Quaternion.identity); 
		player1Up = false;
	}

	void spawnPlayer2(){
		Instantiate (player2, tf.position, Quaternion.identity); 
		player2Up = false;
	}
}
