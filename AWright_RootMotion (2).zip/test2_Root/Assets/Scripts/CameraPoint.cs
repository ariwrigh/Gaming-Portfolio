﻿using UnityEngine;
using System.Collections;

public class CameraPoint : MonoBehaviour
{
	private void Update()
	{
		Plane plane = new Plane (Vector3.up, transform.position);
		Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
		float distance;
		if (plane.Raycast (ray, out distance))
		{
			transform.position = ray.GetPoint (distance);
		}
	}
}