﻿using UnityEngine;
using System.Collections;

public class BallHit : MonoBehaviour {

	void OnTriggerEnter(Collider other) {
		if (other.gameObject.tag == "ship") {
			other.gameObject.SetActive(false);
			Application.LoadLevel ("death1");
		}
	}

}