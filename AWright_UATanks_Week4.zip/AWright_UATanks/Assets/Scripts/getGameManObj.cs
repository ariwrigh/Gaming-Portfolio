﻿using UnityEngine;
using System.Collections;

public class getGameManObj : MonoBehaviour {
	GameManager gameMan;

	// Use this for initialization
	void Start () {
		gameMan = GameObject.FindObjectOfType<GameManager> ();
	}
	
	public void singlePlayerStart(){
		gameMan.GetComponent<GameManager> ().singlePlayerStart ();
		gameMan.GetComponent<GameManager> ().playerOneNC = false;
		gameMan.GetComponent<GameManager> ().playerOneLives = 3;
		gameMan.GetComponent<GameManager> ().playerOneScore = 0;
		gameMan.GetComponent<GameManager> ().numPLayers = 1;
	}

	public void multiPlayerStart(){
		gameMan.GetComponent<GameManager> ().multiPlayerStart();
		gameMan.GetComponent<GameManager> ().playerOneNC = false;
		gameMan.GetComponent<GameManager> ().playerTwoNC = false;
		gameMan.GetComponent<GameManager> ().playerOneLives = 3;
		gameMan.GetComponent<GameManager> ().playerOneScore = 0;
		gameMan.GetComponent<GameManager> ().playerTwoLives = 3;
		gameMan.GetComponent<GameManager> ().playerTwoScore = 0;
		gameMan.GetComponent<GameManager> ().numPLayers = 2;
	}

	public void mainMenu(){
		gameMan.GetComponent<GameManager> ().mainMenu ();
	}
}
