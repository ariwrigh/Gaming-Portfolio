﻿using UnityEngine;
using System.Collections;

public class SampleAIController3 : MonoBehaviour {
	public Transform target;
	private TankData data;
	private Fire shoot;
	private TankMotor motor;  
	private Transform tf;//transform of current object
	private int avoidanceStage = 0;
	public float timeAvoiding = 1.0f;
	private float exitTime;
	private int rotateDirection = -1;
	public enum AIState { Chase, ChaseAndFire, CheckForFlee, Flee, Rest };
	public AIState aiState = AIState.Chase;
	public float stateEnterTime;
	public float aiSenseRadius = 20;
	public int restingHealRate = 1; // in hp/second 
	private float healTime;
	private float lastHeal;
	public float fleeDistance = 1.0f;

	// Use this for initialization
	void Start () {
		data = GetComponentInParent<TankData> ();
		motor = GetComponentInParent<TankMotor> ();
		tf = gameObject.GetComponent<Transform>();
		shoot = gameObject.GetComponent<Fire>();
		lastHeal = Time.time;
	}
	
	// Update is called once per frame

	void Update () {
		if ( aiState == AIState.Chase ) {
			// Perform Behaviors
			if (avoidanceStage != 0) {
				DoAvoidance();
				
			} else {
				DoChase();
			}

			// Check for Transitions
			if (data.health < data.maxHealth * 0.5f) {
				ChangeState(AIState.CheckForFlee);
			} else if (Vector3.Distance (target.position, tf.position) <= aiSenseRadius) {
				ChangeState(AIState.ChaseAndFire);
			}
		} else if ( aiState == AIState.ChaseAndFire ) {
			// Perform Behaviors
			if (avoidanceStage != 0) {
				DoAvoidance();
				
			} else {
				DoChase();

				// Limit our firing rate, so we can only shoot if enough time has passed
				if (shoot.roundFired == false) {
					shoot.Shoot();
					shoot.timeUntilFire = Time.time + shoot.fireDelay;
				}
			}
			// Check for Transitions
			if (data.health < data.maxHealth * 0.5f) {
				ChangeState(AIState.CheckForFlee);
			} else if (Vector3.Distance (target.position, tf.position) > aiSenseRadius) {
				ChangeState(AIState.Chase);
			}
		} 

		else if ( aiState == AIState.Flee ) {
			// Perform Behaviors
			if (avoidanceStage != 0) {
				DoAvoidance();
				
			} else {
				DoFlee();

			}

			// Check for Transitions
			if (Time.time >= stateEnterTime + 10) {
				ChangeState(AIState.CheckForFlee);
			}
		} 
		else if ( aiState == AIState.CheckForFlee ) {
			// Perform Behaviors
			CheckForFlee();

			// Check for Transitions
			if (Vector3.Distance (target.position, tf.position) <= aiSenseRadius) {
				ChangeState(AIState.Flee);
			} else {
				ChangeState(AIState.Rest);
			}
		} else if ( aiState == AIState.Rest ) {
			// Perform Behaviors
			healTime = Time.time;
			DoRest();

			// Check for Transitions
			if (Vector3.Distance (target.position, tf.position) <= aiSenseRadius) {
				ChangeState(AIState.Flee);
			} else if (data.health >= data.maxHealth) {
				ChangeState(AIState.Chase);
			}
		}
	}//end update

	void DoChase(){
		motor.RotateTowards (target.position, data.turnSpeed);
		//check for colisions 1 second away
		//this determins movement possible
		if (CanMove (data.moveSpeed)) {
			motor.Move (data.moveSpeed);
		} else {
			//set move state up one level
			avoidanceStage= 1;
		}
	}

	void DoAvoidance(){
		if (avoidanceStage == 1) {
			//rotate to the left
			motor.Rotate((rotateDirection*data.turnSpeed));

			//if I can move, hit stage 2
			if(CanMove(data.moveSpeed * (Time.time*.25f))){
				avoidanceStage = 2;

				//set time for duration of stage 2
				exitTime = timeAvoiding;
			}
			//if not the above will run again
		}//end move state 1 code
		else if (avoidanceStage == 2){
			//if we can move, do it
			if(CanMove(data.moveSpeed * (Time.time*.25f))){
				//adjust time acordingly and move
				exitTime -= Time.deltaTime;
				motor.Move(data.moveSpeed);

				//check how long avoidance has been occuring to potentially return to chase mode
				if(exitTime <= 0){
					avoidanceStage = 0;
				}
			}//end can move check
			else{
				//movement not possible head back to stage 1
				avoidanceStage = 1;
			}
		}//end move state 2 code
	}

	public void CheckForFlee() {
		// TODO: Write the CheckForFlee state.
	}

	public void DoFlee(){
		//if I can move
		if (CanMove (data.moveSpeed * Time.time)) {
			//Line between the player and ai
			Vector3 vectorToTarget = target.position - tf.position;

			// Set vector to be away from target instead of to it
			Vector3 vectorAwayFromTarget = -1 * vectorToTarget;

			// Adjust Magniture
			vectorAwayFromTarget.Normalize ();

			// Due to normalization, if we multiply by the distance that is the travel distance.
			vectorAwayFromTarget *= fleeDistance;

			// We can find the position in space we want to move to by adding our vector away from our AI to our AI's position.
			//     This gives us a point that is "that vector away" from our current position.
			Vector3 fleePosition = vectorAwayFromTarget + tf.position;
			motor.RotateTowards( fleePosition, data.turnSpeed );
			motor.Move (data.moveSpeed);
		} else {//If can't move start avoidance
			avoidanceStage = 1;
		}
	}

	public void DoRest() {
		// Increase our health. Remember that our increase is "per second"!
		//data.health += (int)(restingHealRate * Time.deltaTime);
		if (healTime >= (lastHeal + 1f)) {
			data.health += restingHealRate;
			lastHeal = Time.time;
		}

		// But never go over our max health
		data.health = Mathf.Min (data.health, data.maxHealth);

	}

	public void ChangeState ( AIState newState ) {
		// Change our state
		aiState = newState;

		// save the time we changed states
		stateEnterTime = Time.time;
	}   

	bool CanMove (float speed){
		//check forward for hit from raycast
		RaycastHit hit;
		if(Physics.Raycast(tf.position, tf.forward, out hit, speed)){
			if(!hit.collider.CompareTag("Player") && !hit.collider.CompareTag("bullet")){//hit something non player non bullet
				//no movement
				rotateDirection = -1;//turn left
				return false;
			}
		}//end if
		//otherwise move
		return true;
	}
}

