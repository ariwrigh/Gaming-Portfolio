﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {
	//create an instance variable to hold game manager object
	public static GameManager instance;

	//manage player enemy instance variables

	GameObject[] playerSpawners;
	GameObject[] enemySpawn;// = GameObject.FindGameObjectsWithTag("Enemy");
	GameObject[] enemySpawners;// = GameObject.FindGameObjectsWithTag("EnemySpawn");

	//public variabel to interact with map generator
	public bool mapOfTheDay = false;

	//player one tracking
	public int playerOneLives = 3;
	public int playerOneScore= 0;

	//player twp tracking
	public int playerTwoLives = 3;
	public int playerTwoScore= 0;

	public bool firstSetup = true;//used to create one of each tank on startup

	[HideInInspector]
	//TODO: Need to create player 1 and player 2 for multi
	public bool playerSpawn = false;//player up? single
	public bool player1Spawn = false;//player up? multi
	public bool player2Spawn = false;//player up? multi
	public bool enemyDestroyed = false;//when enemy destroyed trigger new spawn

	private string sceneName;
	public bool playerOneNC = false;//keep track of no continues
	public bool playerTwoNC = false;//keep track of no continues
	public int numPLayers = 1;

	// Runs before any Start() functions run
	void Awake () {
		if (instance == null) {//check for an instance
			instance = this;//make this if none exists
		}
		else {//ef exists delete new game object instance
			Debug.LogError("ERROR: There can only be one GameManager.");
			Destroy(gameObject);
		}
	}

	// Use this for initialization
	void Start () {
		Scene currentScene = SceneManager.GetActiveScene ();
		sceneName = currentScene.name;
	}
	
	// Update is called once per frame
	void Update () {
		if(numPLayers == 1 && playerOneNC == true){
			gameOver ();
			
		}else if (numPLayers == 2 && playerOneNC == true && playerTwoNC == true){
			gameOverMulti ();
		}

		if (sceneName == "StartScreen" || sceneName == "GameOver") {
			
		} else if(sceneName == "Main"){//single player mode
			if (!playerSpawn) {//if no player spawn
				//get all spawn locations
				playerSpawners = GameObject.FindGameObjectsWithTag ("PlayerSpawn");
				//set playerUp to true to trigger spawn at random locations
				playerSpawners [UnityEngine.Random.Range(0, playerSpawners.Length-1)].GetComponent<PlayerSpawn> ().playerUp = true;
				//set player spawn to true to avoid over populations
				playerSpawn = true;
			}
			if(firstSetup == true){
				//get all spawn locations
				enemySpawners =  GameObject.FindGameObjectsWithTag("EnemySpawn");
				//setup tanks
				tankSetup();
				//set first setup to false to avoid over population
				firstSetup = false;

			} 
			if (enemyDestroyed) {
				//create random number to generate random tank AI
				int temp = UnityEngine.Random.Range (0, 3);
				//get all spawn locations
				//enemySpawners = GameObject.FindGameObjectsWithTag("EnemySpawn");
				if(temp == 0){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnChaseEnemy();
				} else if(temp == 1){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnFleeEnemy();
				} else if(temp == 2){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnMazeEnemy();
				} else if(temp == 3){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnPatrolEnemy();
				}
				//set to false so next trigger can occure
				enemyDestroyed = false;
			}
		//enD single player
		}else if(sceneName == "MainMulti"){//multi player mode
			if (!player1Spawn) {//if no 1 player spawn and not at start
				//get all spawn locations
				playerSpawners = GameObject.FindGameObjectsWithTag ("PlayerSpawn");
				//set playerUp to true to trigger spawn at random locations
				playerSpawners [UnityEngine.Random.Range(0, playerSpawners.Length-1)].GetComponent<PlayerSpawn> ().player1Up = true;
				//set player spawn to true to avoid over populations
				player1Spawn = true;
			}
			if (!player2Spawn) {//if no 2 player spawn and not at start
				//get all spawn locations
				playerSpawners = GameObject.FindGameObjectsWithTag ("PlayerSpawn");
				//set playerUp to true to trigger spawn at random locations
				playerSpawners [UnityEngine.Random.Range(0, playerSpawners.Length-1)].GetComponent<PlayerSpawn> ().player2Up = true;
				//set player spawn to true to avoid over populations
				player2Spawn = true;
			}
			if(firstSetup == true){
				//get all spawn locations
				enemySpawners =  GameObject.FindGameObjectsWithTag("EnemySpawn");
				//setup tanks
				tankSetup();
				//set first setup to false to avoid over population
				firstSetup = false;

			} 
			if (enemyDestroyed == true) {
				//create random number to generate random tank AI
				int temp = UnityEngine.Random.Range (0, 3);
				//get all spawn locations
				//enemySpawners = GameObject.FindGameObjectsWithTag("EnemySpawn");
				if(temp == 0){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnChaseEnemy();
				} else if(temp == 1){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnFleeEnemy();
				} else if(temp == 2){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnMazeEnemy();
				} else if(temp == 3){
					enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnPatrolEnemy();
				}
				//set to false so next trigger can occure
				enemyDestroyed = false;
			}
		}//end multi player

	}

	private void tankSetup(){
		
		//spawn one of each enemy type in random location
		enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnChaseEnemy();
		enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnFleeEnemy();
		enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnMazeEnemy();
		enemySpawners[UnityEngine.Random.Range(0, enemySpawners.Length-1)].GetComponent<EnemySpawn>().spawnPatrolEnemy();
		firstSetup = false;

	}

	public void singlePlayerStart(){
		//keep this active
		DontDestroyOnLoad (this);
		//when starting new map, first setup must be true so tanks will spawn
		firstSetup = true;
		playerSpawn = false;
		//load required scene and adjust scene name accordingly to allow function process
		sceneName = "Main";
		SceneManager.LoadScene("Main");


	}

	public void multiPlayerStart(){
		//keep this active
		DontDestroyOnLoad (this);
		//when starting new map, first setup must be true so tanks will spawn
		firstSetup = true;
		//load required scene and adjust scene name accordingly to allow function process
		sceneName ="MainMulti";
		SceneManager.LoadScene("MainMulti");
		player1Spawn = false;
		player2Spawn = false;


	}

	public void mainMenu(){
		//keep this active
		DontDestroyOnLoad (this);
		//load required scene and adjust scene name accordingly to allow function process
		sceneName = "StartScreen";
		SceneManager.LoadScene("StartScreen");

	}

	public void gameOver(){
		//keep this active
		DontDestroyOnLoad (this);
		//load required scene and adjust scene name accordingly to allow function process
		SceneManager.LoadScene("GameOver");
		sceneName = "GameOver";
		//prevent loop of game over
		playerOneNC = false;
		playerTwoNC = false;
	}

	public void gameOverMulti(){
		//keep this active
		DontDestroyOnLoad (this);
		//load required scene and adjust scene name accordingly to allow function process
		SceneManager.LoadScene("GameOverMuli");
		sceneName = "GameOverMuli";
		//prevent loop of game over
		playerOneNC = false;
		playerTwoNC = false;
	}


	public void updateFalseMOTD(){
		mapOfTheDay = false;
	}

	public void updateTrueMOTD(){
		mapOfTheDay = true;
	}
}
	