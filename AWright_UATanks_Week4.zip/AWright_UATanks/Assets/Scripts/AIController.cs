﻿using UnityEngine;
using System.Collections;

public class AIController : MonoBehaviour {
	public Transform[] waypoints;
	public Transform[] patrolRoute;
	private int currentWaypoint = 0;
	public float closeEnough = 1.0f;
	private bool maxWaypointReached = false;
	public Transform target;
	private TankData data;
	private Fire shoot;
	private TankMotor motor;  
	private Transform tf;//transform of current object
	public GameObject maze;
	public GameObject patrol;
	public GameObject chase;
	public GameObject flee;
	private int avoidanceStage = 0;
	public float timeAvoiding = 1.0f;
	private float exitTime;
	public float stateEnterTime;
	public float aiSenseRadius = 20;
	public float fleeDistance = 1.0f;
//	public enum AIState { Chase, ChaseAndFire, CheckForFlee, Flee, Rest };
//	public AIState aiState = AIState.Chase;
	public enum AIPersonality { Maze, Patrol, Chase, Flee};
	public AIPersonality aiPersonality = AIPersonality.Maze;
	float rotateSpeed;//for patrol only


	// Use this for initialization
	void Start () {
		data = GetComponentInParent<TankData> ();
		motor = GetComponentInParent<TankMotor> ();
		tf = gameObject.GetComponent<Transform>();
		shoot = gameObject.GetComponent<Fire>();
		rotateSpeed = (-1*data.turnSpeed);//for patrol only
	}
	
	// Update is called once per frame
	void Update () {
		if(target == null){
			Transform tesTarget1 = GameObject.FindGameObjectWithTag ("Player").transform;
			Transform tesTarget2 = GameObject.FindGameObjectWithTag ("Player2").transform;
			if (tesTarget1 != null) {//check for player 1
				target = GameObject.FindGameObjectWithTag ("Player").transform;
			} else if (tesTarget2 != null) {//if cant find, then player 2
				target = GameObject.FindGameObjectWithTag ("Player2").transform;
			} else {//if cant find any, for some reason, change AI from target based to Path based
				aiPersonality = AIPersonality.Maze;
			}
		}
		if(aiPersonality == AIPersonality.Maze){
			maze.SetActive(true);
			patrol.SetActive(false);
			chase.SetActive(false);
			flee.SetActive(false);
			if (motor.RotateTowards (waypoints [currentWaypoint].position, data.turnSpeed)) {
				//If rotating Do nothing!!
			} else {
				//Move forward
				motor.Move(data.moveSpeed);
			}
			if (Vector3.SqrMagnitude (waypoints [currentWaypoint].position - tf.position) < (closeEnough * closeEnough)) {
				if (maxWaypointReached == false) {
					//Set next way point
					currentWaypoint++;
					if (currentWaypoint == (waypoints.Length - 1)) {
						maxWaypointReached = true;//if next waypoint is end of array indicate max reached
					}
				} else {//when reaching end of array begin backtrack through waypoint to first object
					currentWaypoint--;
					if (currentWaypoint == 0) {//when begining is reached, start cycle over
						maxWaypointReached = false;
					}
				}
			}

		}//end maze
		if (aiPersonality == AIPersonality.Flee) {
			maze.SetActive (false);
			patrol.SetActive (false);
			chase.SetActive (false);
			flee.SetActive (true);
			if (Vector3.Distance (target.position, tf.position) <= aiSenseRadius) {//if close enough run
				if (avoidanceStage != 0) {
					DoAvoidance ();
				} else {
					DoFlee();
				}

			}

		}// end flee
		if (aiPersonality == AIPersonality.Chase) {
			maze.SetActive (false);
			patrol.SetActive (false);
			chase.SetActive (true);
			flee.SetActive (false);
			if (avoidanceStage != 0) {
				DoAvoidance ();
			} else {
				DoChase();
			}



		}// end chase

		if (aiPersonality == AIPersonality.Patrol) {
			maze.SetActive (false);
			patrol.SetActive (true);
			chase.SetActive (false);
			flee.SetActive (false);

			if (Vector3.Distance (target.position, tf.position) <= aiSenseRadius) {//if close enough to hear
				motor.Rotate (rotateSpeed);
//				Vector3 forward = tf.TransformDirection (Vector3.forward) * 10;
//				Debug.DrawRay (tf.position, forward, Color.green);
				RaycastHit hit;
				if (Physics.Raycast (tf.position, tf.forward, out hit, aiSenseRadius)) {
					if (hit.collider.CompareTag ("Player")) {//hit player
						rotateSpeed = 0.0f;
						// Limit our firing rate, so we can only shoot if enough time has passed
						if (shoot.roundFired == false) {
							shoot.Shoot ();
							shoot.timeUntilFire = Time.time + shoot.fireDelay;
						}

					} else {//if hit non player item
						rotateSpeed = (-1 * data.turnSpeed);
					} 

				} else {
					rotateSpeed = (-1 * data.turnSpeed);
				}
			}else{
					//basic patrol start
					if (motor.RotateTowards (patrolRoute [currentWaypoint].position, data.turnSpeed)) {
						//If rotating Do nothing!!
					} else {
						//Move forward
						motor.Move (data.moveSpeed);
					}
					if (Vector3.SqrMagnitude (patrolRoute [currentWaypoint].position - tf.position) < (closeEnough * closeEnough)) {
						if (maxWaypointReached == false) {
							//Set next way point
							currentWaypoint++;
							if (currentWaypoint == (patrolRoute.Length - 1)) {
								maxWaypointReached = true;//if next waypoint is end of array indicate max reached
							}
						} else {//when reaching end of array begin backtrack through waypoint to first object
							currentWaypoint--;
							if (currentWaypoint == 0) {//when begining is reached, start cycle over
								maxWaypointReached = false;
							}
						}
					}
				}//end basic patrol
		

		}// end patrol
	}//end update


	void DoChase(){
		motor.RotateTowards (target.position, data.turnSpeed);
		//check for colisions 1 second away
		//this determins movement possible
		if (CanMove (data.moveSpeed)) {
			motor.Move (data.moveSpeed);
		} else {
			//set move state up one level
			avoidanceStage= 1;
		}
	}


	void DoFlee(){
		//if I can move
		if (CanMove(data.moveSpeed * (Time.time*.25f))){
			//Line between the player and ai
			Vector3 vectorToTarget = target.position - tf.position;

			// Set vector to be away from target instead of to it
			Vector3 vectorAwayFromTarget = (-1 * vectorToTarget);

			// Adjust Magniture
			vectorAwayFromTarget.Normalize ();

			// Due to normalization, if we multiply by the distance that is the travel distance.
			vectorAwayFromTarget *= fleeDistance;

			// We can find the position in space we want to move to by adding our vector away from our AI to our AI's position.
			//     This gives us a point that is "that vector away" from our current position.
			Vector3 fleePosition = vectorAwayFromTarget + tf.position;
			motor.RotateTowards( fleePosition, data.turnSpeed );
			motor.Move (data.moveSpeed);
		} else {//If can't move start avoidance
			avoidanceStage = 1;
		}
	}//end doflee

	void DoAvoidance(){
		if (avoidanceStage == 1) {
			//rotate to the left
			motor.Rotate((-1*data.turnSpeed));

			//if I can move, hit stage 2
			if(CanMove(data.moveSpeed * (Time.time*.25f))){
				avoidanceStage = 2;

				//set time for duration of stage 2
				exitTime = timeAvoiding;
			}
			//if not the above will run again
		}//end move state 1 code
		else if (avoidanceStage == 2){
			//if we can move, do it
			if(CanMove(data.moveSpeed * (Time.time*.25f))){
				//adjust time acordingly and move
				exitTime -= Time.deltaTime;
				motor.Move(data.moveSpeed);

				//check how long avoidance has been occuring to potentially return to chase mode
				if(exitTime <= 0){
					avoidanceStage = 0;
				}
			}//end can move check
			else{
				//movement not possible head back to stage 1
				avoidanceStage = 1;
			}
		}//end move state 2 code
	}


	bool CanMove (float speed){
		//check forward for hit from raycast
		RaycastHit hit;
		if(Physics.Raycast(tf.position, tf.forward, out hit, speed)){
			if(!hit.collider.CompareTag("Player") && !hit.collider.CompareTag("bullet")){//hit something non player non bullet
				//no movement
				return false;
			}
		}//end if
		//otherwise move
		return true;
	}//end canmove

	public void updateWayPoints(Transform[] waypoint){
		this.waypoints = waypoint;
	}

	public void updatePatrolPoints(Transform[] waypoint){
		this.patrolRoute = waypoint;
	}

}
