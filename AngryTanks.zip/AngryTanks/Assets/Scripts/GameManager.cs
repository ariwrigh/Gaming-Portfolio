﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {
	public static GameManager instance; //our game manager singleton
	[HideInInspector]//hides below variables from inspector
	public int levelsBeat = 0;

	//runs before any start functions
	void Awake(){
		if (instance == null) {
			instance = this;
		} else {
			Debug.LogError("ERROR: There can be only one GameManager.");
			Destroy (gameObject);
		}
		DontDestroyOnLoad (transform.gameObject);//keeps Game manager from being destroyed
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	}
}
