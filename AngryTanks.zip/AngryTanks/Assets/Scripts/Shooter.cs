﻿using UnityEngine;
using System.Collections;

public class Shooter : MonoBehaviour {
	
	public GameObject prefabBullet; // The prefab to hold our bullet
	public float minThrowForce = 50;//min force applied to bullet
	public float maxThrowForce = 2000;//max force applied to bullet
	public float chargeSpeed = 200;//charge rate for force
	float throwForce; // The amount of force to use to throw the bullet
	public bool roundFired = false;//check for reload

	
	// Use this for initialization
	void Start () {
		throwForce = minThrowForce;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetButton("Fire1") && throwForce < maxThrowForce && roundFired == false) {
			//modifies throwforce based on time fire button is heald down
			throwForce += Time.deltaTime * chargeSpeed;
			//print throwforce to consel
			Debug.Log(throwForce);
		}
		if (Input.GetButtonUp("Fire1") && roundFired == false) {
			
			// Create a bullet and store it in a GameObject variable
			GameObject theBullet;
			theBullet = Instantiate (prefabBullet, transform.position + transform.forward, Quaternion.identity) as GameObject;
			
			// Add force to the bullet we created -- the force vector is the object's forward direction scaled by the amount of force!
			theBullet.GetComponent<Rigidbody>().AddForce(throwForce * transform.forward);

			//reset throwforce to min val to reset charge
			throwForce = minThrowForce;

			//shots fired need reload!!!
			roundFired = true;
		}
		if (Input.GetButtonUp("Fire2")) {
			// reload the cannon!!!!
			roundFired = false;

		}
		if (Input.GetButtonUp("Cancel")) {
			//quit game
			Application.Quit();
			
		}
	}
}