﻿using UnityEngine;
using System.Collections;

public class BallHitAfterFirstDeath : MonoBehaviour {
		void OnTriggerEnter(Collider other) {
			if (other.gameObject.tag == "ship") {
				other.gameObject.SetActive(false);
				Application.LoadLevel ("death2");
			}
		}
		
	}