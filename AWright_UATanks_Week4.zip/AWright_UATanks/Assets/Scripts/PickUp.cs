﻿using UnityEngine;
using System.Collections;

public class PickUp : MonoBehaviour {
	public Powerup powerup;
	public AudioClip feedback; 
	private Transform tf;//transform of current object

	// Use this for initialization
	void Start () {
		tf = gameObject.GetComponent<Transform>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void OnTriggerEnter (Collider other) {
		// variable to store other object's PowerupController - if it has one
		PowerupController powCon = other.GetComponent<PowerupController> ();

		// If the other object has a PowerupController
		if (powCon != null) {
			// Add the powerup
			powCon.Add (powerup);

			// Play Feedback (if it is set)
			if (feedback != null) {
				AudioSource.PlayClipAtPoint( feedback, tf.position, 1.0f);
			}

			// Destroy this powerup
			Destroy (gameObject);
		}
	}
}
