﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class TankData : MonoBehaviour {
	public float moveSpeed = 3; // in meters per second move speed
	public float turnSpeed = 180; // in degrees per second
	public int health = 100;
	public int score = 0;
	public int pointValue = 10;
	string sceneName;

	//[HideInInspector]//hide below variables
	public int maxHealth;
	public int lives;

	// Use this for initialization
	void Start () {
		Scene currentScene = SceneManager.GetActiveScene ();
		sceneName = currentScene.name;

		//set max health = tank health at start
		maxHealth = health;
		//set starting values based on game mode
		if(sceneName == "Main"){
			lives = GameObject.FindObjectOfType<GameManager> ().playerOneLives;
			score = GameObject.FindObjectOfType<GameManager> ().playerOneScore;
		}else if (sceneName == "MainMulti"){
			if(this.gameObject.tag == "Player"){
				lives = GameObject.FindObjectOfType<GameManager> ().playerOneLives;
				score = GameObject.FindObjectOfType<GameManager> ().playerOneScore;
			}else if (this.gameObject.tag == "Player2"){
				lives = GameObject.FindObjectOfType<GameManager> ().playerTwoLives;
				score = GameObject.FindObjectOfType<GameManager> ().playerTwoScore;
			}
		}

	}

	void OnCollisionEnter(Collision other){
		if(other.gameObject.tag == "bullet"){
			if ((health - other.gameObject.GetComponent<BulletData> ().damage) <= 0) {
				//other.transform.parent.GetComponent<TankData> ().score += this.pointValue;
				GameObject test = other.gameObject.GetComponent<BulletData>().owner;
				test.GetComponent<TankData>().score += this.pointValue;

			}
			int dmg = other.gameObject.GetComponent<BulletData> ().damage;
			Destroy (other.gameObject);
			health = (health - dmg);
		}
	}

	// Update is called once per frame
	void Update () {
		if(sceneName == "Main"){//single player
			if(health <= 0){
				if (this.gameObject.tag == "Player") {//if player destroyed
					lives -=1;
					GameObject.FindObjectOfType<GameManager> ().playerOneLives -= 1;
					if (lives > 0) {
						GameObject.FindObjectOfType<GameManager> ().playerOneScore = score;
						//indicate to game manager no players are spawned
						GameObject.FindObjectOfType<GameManager> ().playerSpawn = false;
						Destroy (this.gameObject);
					} else {
						//TODO load game over screen
						GameObject.FindObjectOfType<GameManager> ().playerOneNC = true;

						//indicate to game manager no players are spawned
						GameObject.FindObjectOfType<GameManager> ().playerSpawn = false;
						PlayerPrefs.SetInt("Player1Score", score);
						PlayerPrefs.Save ();

					}

				} else {//if enemy destroyed
					//indicate to game manager that enemy needs to be spawned
					GameObject.FindObjectOfType<GameManager> ().enemyDestroyed = true;
					Destroy (this.gameObject);
				}

			}
		}//end single player
		else if (sceneName == "MainMulti"){//multi player
			if (health <= 0) {
				if (this.gameObject.tag == "Player") {//if player 1 destroyed
					lives -= 1;
					GameObject.FindObjectOfType<GameManager> ().playerOneLives -= 1;
					if (lives > 0) {
						GameObject.FindObjectOfType<GameManager> ().playerOneScore = score;
						//indicate to game manager no players are spawned
						GameObject.FindObjectOfType<GameManager> ().player1Spawn = false;
						Destroy (this.gameObject);
					} else {
						
						GameObject.FindObjectOfType<GameManager> ().playerOneNC = true;

						//indicate to game manager no players are spawned
						//GameObject.FindObjectOfType<GameManager> ().player1Spawn = false;
						PlayerPrefs.SetInt ("Player1Score", score);
						PlayerPrefs.Save ();
						//gameObject.GetComponent<UpdateLives>().livesText.text = "0";
						this.gameObject.SetActive (false);
					}

				}else if(this.gameObject.tag == "Player2"){
					lives -= 1;
					GameObject.FindObjectOfType<GameManager> ().playerTwoLives -= 1;
					if (lives > 0) {
						GameObject.FindObjectOfType<GameManager> ().playerTwoScore = score;
						//indicate to game manager no players are spawned
						GameObject.FindObjectOfType<GameManager> ().player2Spawn = false;
						Destroy (this.gameObject);
					} else {

						GameObject.FindObjectOfType<GameManager> ().playerTwoNC = true;

						//indicate to game manager no players are spawned
						//GameObject.FindObjectOfType<GameManager> ().player2Spawn = false;
						PlayerPrefs.SetInt ("Player2Score", score);
						PlayerPrefs.Save ();
						//gameObject.GetComponent<UpdateLives>().livesText.text = "0";
						this.gameObject.SetActive (false);

					}
				}else {//if enemy destroyed
					//indicate to game manager that enemy needs to be spawned
					GameObject.FindObjectOfType<GameManager> ().enemyDestroyed = true;
					Destroy (this.gameObject);
				}

			}
		}//end multi player

	}
		
}
