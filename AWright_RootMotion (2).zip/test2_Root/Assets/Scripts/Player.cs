﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Player : MonoBehaviour 
{
	[SerializeField, Tooltip("The max speed of the player")]
	private float speed = 2f; 
	[SerializeField, Tooltip("The max look speed of the player (degrees)")]
	private float lookSpeed = 90f; 

	public Text sprintText;

	private Animator animator;
	private Vector2 center;
	[HideInInspector]
	public float sprintTime = 100f;
	[HideInInspector]
	public bool sprintActive = true;

	private void Start(){
		center.x= (Screen.width / 2.0f);
		center.y = (Screen.height / 2.0f);
	}

	private void Awake()
	{
		
		animator = gameObject.GetComponent<Animator>();
	}


	private void Update()
	{
		Vector3 input = new Vector3 (Input.GetAxis ("Horizontal"), 0f, Input.GetAxis ("Vertical"));
		input = Vector3.ClampMagnitude (input, 1f);
		//input = transform.InverseTransformDirection (input);
		input *= speed;
		animator.SetFloat ("Horizontal", input.x);
		animator.SetFloat ("Vertical", input.z);

		if (System.Math.Abs (Input.mousePosition.x - center.x) <= 25) {//if cursor in middle of screen
			//do nothing
		} else {//get mouse position
			var v3 = Input.mousePosition;
			v3.z = 20.0f;//set z variable 20 away from camera
			v3 = Camera.main.ScreenToWorldPoint(v3);//convert vector three to world space
			v3.y = 1f; //set y variable to avoid character rotating up accross x or z axis to view odd Y locations
			//rotate player
			Quaternion targetRotation = Quaternion.LookRotation (v3 - transform.position);
			transform.rotation = Quaternion.RotateTowards (transform.rotation, targetRotation, lookSpeed * Time.deltaTime);
		}

		//sprint
		if (Input.GetKey ("right shift") && sprintTime > 0f && sprintActive == true || Input.GetKey ("left shift") && sprintTime > 0f && sprintActive == true){
			speed = 4f;
			sprintTime -= .5f;
		} else {
			speed = 2f;
			if (sprintTime >= 100f) {
				sprintTime = 100f;
				sprintActive = true;
				sprintText.text = "Sprint Active";
			} else {
				sprintTime += .75f;
				sprintActive = false;
				sprintText.text = "Sprint Charging";
			}
		}

	} 
}