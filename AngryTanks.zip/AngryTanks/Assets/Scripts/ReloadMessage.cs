﻿using UnityEngine;
using System.Collections;

public class ReloadMessage : MonoBehaviour {
	public GameObject canvasLayer;
	bool needReload;
	private Shooter shooterScript;

	// Use this for initialization
	void Start () {
		shooterScript = FindObjectOfType (typeof(Shooter)) as Shooter;
	}
	
	// Update is called once per frame
	void Update () {
		//needReload = gameObject.GetComponent<roundFired>;
		if (shooterScript.roundFired == true) {
			canvasLayer.SetActive (true);
		} else {
			canvasLayer.SetActive(false);
		}
	}
}
