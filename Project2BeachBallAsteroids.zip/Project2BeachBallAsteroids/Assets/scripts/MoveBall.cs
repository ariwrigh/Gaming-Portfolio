﻿using UnityEngine;
using System.Collections;

public class MoveBall : MonoBehaviour {
	public float speed = .05f;

	// Use this for initialization
	void Start () {
		// Change asteroid position to outside of scene based on random number generation between 0 and 1
		float randomFloat = Random.value;
		if (randomFloat <= .125f) {
			transform.position = new Vector3 (-17, 17, transform.position.z);
		}
		else if (randomFloat > .125f && randomFloat <= .25f) {
			transform.position = new Vector3 (0, 11, transform.position.z);
		}
		else if (randomFloat > .375f && randomFloat <= .5f) {
			transform.position = new Vector3 (17, 17, transform.position.z);
		}
		else if (randomFloat > .5f && randomFloat <= .625f) {
			transform.position = new Vector3 (-17, -17, transform.position.z);
		}
		else if (randomFloat > .625f && randomFloat <= .75f) {
			transform.position = new Vector3 (17, -17, transform.position.z);
		}
		else if (randomFloat > .75f && randomFloat <= .875f) {
			transform.position = new Vector3 (0, -11, transform.position.z);
		}
		else if (randomFloat > .25f && randomFloat <= .375f) {
			transform.position = new Vector3 (17, 0, transform.position.z);
		}
		else if (randomFloat > .875f && randomFloat <= 1.0f) {
			transform.position = new Vector3 (-17, 0, transform.position.z);
		}

	}
	

	// Update is called once per frame
	void Update () {
		//make a copy of current position
		Vector3 myposition = transform.position;
		//begin checking if values are greater than 0
		//then start incrimenting objects to 0,0,0 where ship is located
		if (myposition.x < 0) {
			float newX = transform.position.x + speed;
			Vector3 tempVec = new Vector3(newX, transform.position.y,transform.position.z);
			transform.position = tempVec;
		}
		if (myposition.x > 0) {
			float newX = transform.position.x - speed;
			Vector3 tempVec = new Vector3(newX, transform.position.y,transform.position.z);
			transform.position = tempVec;
		}
		if (myposition.y < 0) {
			float newY = transform.position.y + speed;
			Vector3 tempVec = new Vector3(transform.position.x, newY,transform.position.z);
			transform.position = tempVec;
		}
		if (myposition.y > 0) {
			float newY = transform.position.y - speed;
			Vector3 tempVec = new Vector3(transform.position.x, newY,transform.position.z);
			transform.position = tempVec;
		}
	}
}
