﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Powerup {
	//modifiers
	public float speedModifier;
	public int healthModifier;
	public int maxHealthModifier;
	//duration
	public float duration;
	public bool isPermanent;

	public void OnActivate (TankData target) {
		target.moveSpeed += speedModifier;
		target.maxHealth += maxHealthModifier;
		if((target.health + healthModifier)>= target.maxHealth){
			target.health = target.maxHealth;
		}else{
			target.health += healthModifier;
		}
	}

	public void OnDeactivate (TankData target) {
		target.moveSpeed -= speedModifier;
		target.health -= healthModifier;
		target.maxHealth -= maxHealthModifier;
	}

}
