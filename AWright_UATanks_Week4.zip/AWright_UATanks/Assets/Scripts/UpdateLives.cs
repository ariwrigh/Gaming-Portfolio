﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UpdateLives : MonoBehaviour {
	Text livesText;
	TankData player;
	
	// Use this for initialization
	void Start () {
		livesText = GetComponent<Text> ();
		player = gameObject.GetComponentInParent<TankData> ();
	}
	
	// Update is called once per frame
	void Update () {
		livesText.text = player.lives.ToString();
	}
}
