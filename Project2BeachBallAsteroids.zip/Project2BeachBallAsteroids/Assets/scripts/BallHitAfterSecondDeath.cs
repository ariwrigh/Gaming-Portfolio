﻿using UnityEngine;
using System.Collections;

public class BallHitAfterSecondDeath : MonoBehaviour {
	void OnTriggerEnter(Collider other) {
		if (other.gameObject.tag == "ship") {
			other.gameObject.SetActive(false);
			Application.LoadLevel ("death3");
		}
	}
	
}