﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {
	public static GameManager instance; //our game manager singleton
	public Rigidbody beachBall;
	public Vector3 spawnPoint; // The location to spawn beachballs
	// Runs before any Start() functions run
	void Awake () {
		if (instance == null) {
			instance = this;
		}
		else {
			Debug.LogError("ERROR: There can only be one GameManager.");
			Destroy(gameObject);
		}
	}

	// Use this for initialization
	void Start () {
	
	}

	void SpawnBall(){
		//variable to store asteroid
		Rigidbody tempBall;
		//create instance of beachball and store it
		tempBall = Instantiate (beachBall, spawnPoint, Quaternion.identity) as Rigidbody;



	}
	// Update is called once per frame
	void Update () {
		if(GameObject.FindGameObjectsWithTag ("ball").Length < 3 && GameObject.FindWithTag("ship").activeInHierarchy == true)
		{
			SpawnBall ();
		}
	}
}
