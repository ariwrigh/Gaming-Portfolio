﻿using UnityEngine;
using System.Collections;
using System;

public class SpawnPowerUp : MonoBehaviour {
	public float spawnDelay;
	private float nextSpawnTime;
	private Transform tf;
	private GameObject spawnedPickup;
	public GameObject[] pickupPrefabs;

	// Use this for initialization
	void Start () {
		tf = gameObject.GetComponent<Transform> ();
		nextSpawnTime = Time.time + spawnDelay;
	}
	
	// Update is called once per frame
	void Update () {
		//if it is there nothing will spawn
		if (spawnedPickup == null) {
			//if it is time to spawn a pickup
			if (Time.time > nextSpawnTime) {
				//spawn it and set the next time
				spawnedPickup = Instantiate (RandomPowerPrefab (), tf.position, Quaternion.identity) as GameObject;
				nextSpawnTime = Time.time + spawnDelay;
			}
		} else {
			//otherwise, the object still exists, so postpone spawn
			nextSpawnTime = Time.time + spawnDelay;
		}


	}

	// Returns a random room
	public GameObject RandomPowerPrefab () {
		return pickupPrefabs[UnityEngine.Random.Range(0, pickupPrefabs.Length)];
	}

}
