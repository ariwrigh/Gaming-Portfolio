﻿using UnityEngine;
using System.Collections;

public class SampleAIController : MonoBehaviour {
	public Transform[] waypoints;
	public TankData data;
	public TankMotor motor;
	private int currentWaypoint = 0;
	public float closeEnough = 1.0f;
	public Transform tf;
	private bool maxWaypointReached = false;
	public enum LoopType { Stop, Loop, PingPong };
	public LoopType loopType; 


	// Use this for initialization
	void Start () {
		tf = gameObject.GetComponent<Transform>();
	}

	// Update is called once per frame
	void Update () {
		if (motor.RotateTowards (waypoints [currentWaypoint].position, data.turnSpeed)) {
			//If rotating Do nothing!!
		} else {
			//Move forward
			motor.Move(data.moveSpeed);
		}
		if (Vector3.SqrMagnitude (waypoints [currentWaypoint].position - tf.position) < (closeEnough * closeEnough)) {
			if (loopType == LoopType.Loop) {
				if (maxWaypointReached == false) {
					//Set next way point
					currentWaypoint++;
					if (currentWaypoint == (waypoints.Length-1)) {
						maxWaypointReached = true;//if next waypoint is end of array indicate max reached
					}
				} else {//when reaching end of array head to start
					currentWaypoint = 0;
					maxWaypointReached = false;
				}
			}//end loop type loop
			else if(loopType == LoopType.Stop){
				if (maxWaypointReached == true) {
					data.moveSpeed = 0.0f;//full stop if at end of array list
				}
				if (maxWaypointReached == false) {
					//Set next way point
					currentWaypoint++;
					if (currentWaypoint == (waypoints.Length-1)) {
						maxWaypointReached = true;//if next waypoint is end of array indicate max reached
					}
				}

			}//end loop type stop
			else if(loopType == LoopType.PingPong){
				if (maxWaypointReached == false) {
					//Set next way point
					currentWaypoint++;
					if (currentWaypoint == (waypoints.Length-1)) {
						maxWaypointReached = true;//if next waypoint is end of array indicate max reached
					}
				} else {//when reaching end of array begin backtrack through waypoint to first object
					currentWaypoint--;
					if (currentWaypoint == 0) {//when begining is reached, start cycle over
						maxWaypointReached = false;
					}
				}
			}//end loop type ping pong
		}
	}
}
