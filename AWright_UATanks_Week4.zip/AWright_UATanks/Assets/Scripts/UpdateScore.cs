﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class UpdateScore : MonoBehaviour {
	Text scoreText;
	TankData player;

	// Use this for initialization
	void Start () {
		scoreText = GetComponent<Text> ();
		player = gameObject.GetComponentInParent<TankData> ();
	}

	// Update is called once per frame
	void Update () {
		scoreText.text = player.score.ToString();
	}
}
