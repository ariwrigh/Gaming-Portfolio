﻿using UnityEngine;
using System.Collections;

public class VolumeControlUp : MonoBehaviour {
	public void OnValueChanged(float newValue)
	{
		foreach (AudioSource a in FindObjectsOfType<AudioSource>()) {
			a.volume = newValue;
		}

	}

}
