﻿using UnityEngine;
using System.Collections;

public class ButtonEnable : MonoBehaviour {

	public void buttonOn(){
		this.gameObject.SetActive (true);
	}
}
