﻿using UnityEngine;
using System.Collections;

public class LoadGamePlay : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnMouseUp () {
		// loads game level
		Application.LoadLevel("gameplay");
	}
}
