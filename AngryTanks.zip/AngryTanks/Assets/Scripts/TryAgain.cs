﻿using UnityEngine;
using System.Collections;

public class TryAgain : MonoBehaviour {
	private GameManager gameManager;
	// Use this for initialization
	void Start () {
		gameManager = FindObjectOfType (typeof(GameManager)) as GameManager;
	}
	
	// Update is called once per frame
	void Update () {
	}

	void OnMouseUp () {
		// load current failed level
		// levels beat is stored in game manager, each level beat incriments starting index of 4(level 1)
		Application.LoadLevel(4+gameManager.levelsBeat);
	}
}
