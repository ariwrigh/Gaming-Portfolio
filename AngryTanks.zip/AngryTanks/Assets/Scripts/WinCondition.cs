﻿using UnityEngine;
using System.Collections;

public class WinCondition : MonoBehaviour {
	private GameManager gameManager;
	[HideInInspector]//hides below variables from inspector
	public int conditionsMet = 0;

	// Use this for initialization
	void Start () {
		gameManager = FindObjectOfType (typeof(GameManager)) as GameManager;
	}
	
	// Update is called once per frame
	void Update () {
	if (conditionsMet == 3) {
			//records current level as beaten in game manager
			gameManager.levelsBeat += 1;
			Application.LoadLevel("victoryMenu");
		}
	}
}
