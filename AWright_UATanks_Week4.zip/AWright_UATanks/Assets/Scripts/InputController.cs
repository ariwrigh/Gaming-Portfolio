﻿using UnityEngine;
using System.Collections;

public class InputController : MonoBehaviour {
	public TankMotor motor;
	public TankData data;
	//enums for movement
	public enum InputScheme { WASD, arrowKeys };
	public InputScheme input = InputScheme.WASD;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		switch (input) {
		case InputScheme.arrowKeys:
			if (Input.GetKey(KeyCode.UpArrow)){
				motor.Move(data.moveSpeed);
			}
			if (Input.GetKey(KeyCode.DownArrow)){
				motor.Move(-data.moveSpeed);
			}
			if (Input.GetKey(KeyCode.RightArrow)){
				motor.Rotate(data.turnSpeed);
			}
			if (Input.GetKey(KeyCode.LeftArrow)){
				motor.Rotate(-data.turnSpeed);
			}
			break;
		case InputScheme.WASD:
			if (Input.GetKey (KeyCode.W)) {
				motor.Move (data.moveSpeed);
			}
			if (Input.GetKey(KeyCode.S)){
				motor.Move(-data.moveSpeed);
			}
			if (Input.GetKey(KeyCode.D)){
				motor.Rotate(data.turnSpeed);
			}
			if (Input.GetKey(KeyCode.A)){
				motor.Rotate(-data.turnSpeed);
			}
			break;
		}
	}
}

