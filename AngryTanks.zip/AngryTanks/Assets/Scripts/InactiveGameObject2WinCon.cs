﻿using UnityEngine;
using System.Collections;

//this will trigger certain game objects to be set inactive upon 2 win cons being met
public class InactiveGameObject2WinCon : MonoBehaviour {
	private WinCondition winConScript;
	// Use this for initialization
	void Start () {
		winConScript = FindObjectOfType (typeof(WinCondition)) as WinCondition;
	}
	
	// Update is called once per frame
	void Update () {
	if (winConScript.conditionsMet == 2) {
			gameObject.SetActive(false);
		}
	}
}
