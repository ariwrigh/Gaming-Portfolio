﻿using UnityEngine;
using System.Collections;

public class ButtonTEst : MonoBehaviour {
	public void TestTheButton () {
		Debug.Log ("The button was pressed.");
	}
}
