﻿using UnityEngine;
using System.Collections;

public class BulletHit : MonoBehaviour {
	void OnTriggerEnter(Collider other) {
		if (other.gameObject.tag == "ball") {
			Destroy (other.gameObject);
			Destroy (gameObject);
		}
	}
}